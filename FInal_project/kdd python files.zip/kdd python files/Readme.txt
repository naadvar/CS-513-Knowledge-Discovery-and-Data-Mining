The main kdd-main file is the major part of the project.
The kdd-part two is the second part of the project using deep learning.
